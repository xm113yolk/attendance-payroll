# نظام الحضور والمرتبات — Android

هذا المشروع يغلف نسخة v8 HTML كتطبيق Android يعمل دون خادم، مع WebView وتخزين LocalStorage ودعم اختيار الصور/الكاميرا عبر file chooser.

## بناء APK على GitHub
1. ارفع المشروع كاملًا إلى مستودع GitHub.
2. افتح Actions.
3. شغّل `Build Android APK`.
4. بعد نجاح البناء افتح الـworkflow ثم قسم Artifacts.
5. نزّل `attendance-payroll-v1` وستجد `app-debug.apk`.
